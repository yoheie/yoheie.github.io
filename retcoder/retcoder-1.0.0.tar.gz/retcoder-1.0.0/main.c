#include "retcoder.h"

void printcmsg(FILE *cmsgout, char *fname, RcType ifiletype);

int main(int argc, char *argv[]){

  int i, optnum, isoptok;
  RcType ifiletype;
  RcActDef actdef;

  FILE *cmsgout=stdout;
  FILE *ifile;

  actdef.ifconvert = 1;
  actdef.ifcheck = 0;
  actdef.itype = cMIX;
  actdef.otype = cMIX;

  optnum = argc;

  isoptok = checkopts(&optnum, argv, &actdef);

  if(isoptok == 0 || (actdef.ifconvert == 0 && actdef.ifcheck == 0)){
    helpmsg(isoptok);
    return isoptok;
  }

  if(actdef.ifconvert) 
    cmsgout = stderr;

  if(argc == optnum){
    ifiletype = retconv(actdef,stdin);
    if(actdef.ifcheck)
      printcmsg(cmsgout,"stdin",ifiletype);
  }
  else{
    for(i=optnum;i<argc;i++){
      if(ifile=fopen(argv[i],"r")){
        ifiletype = retconv(actdef,ifile);
        if(actdef.ifcheck)
          printcmsg(cmsgout,argv[i],ifiletype);
        fclose(ifile);
      }
      else
        fprintf(stderr,"retcoder: err: file %s not found!!\n",argv[i]);
    }
  }
  return 0;
}

void printcmsg(FILE *cmsgout, char *fname, RcType ifiletype){

  switch(ifiletype){
    case cMIX:
      fprintf(cmsgout,"%s:\tMIXED\n",fname);
      break;
    case cMAC:
      fprintf(cmsgout,"%s:\tMAC\n",fname);
      break;
    case cUNIX:
      fprintf(cmsgout,"%s:\tUNIX\n",fname);
      break;
    case cDOS:
      fprintf(cmsgout,"%s:\tDOS\n",fname);
      break;
    default:
      fprintf(cmsgout,"%s:\tNORC\n",fname);
      break;
  }

  return;
}
