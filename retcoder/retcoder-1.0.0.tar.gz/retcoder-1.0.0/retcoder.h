#ifndef __RETCODER_H__
#define __RETCODER_H__

#include <stdio.h>

typedef enum RcType{
  cNORC,cMAC,cUNIX,cDOS,cMIX
}RcType;

typedef struct RcActDef{
  int ifconvert;
  int ifcheck;
  RcType itype;
  RcType otype;
}RcActDef;

#endif /* __RETCODER_H__ */
