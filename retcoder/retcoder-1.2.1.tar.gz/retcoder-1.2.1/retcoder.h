#ifndef RETCODER_H__
#define RETCODER_H__

#include <stdio.h>

typedef enum RcType{
  cNORC,cMAC,cUNIX,cDOS,cMIX
}RcType;

typedef struct RcActDef{
  int ifconvert;
  int ifcheck;
  RcType otype;
}RcActDef;

int checkopts(int *optnum, char **argv, RcActDef *actdef);
void helpmsg(int isoptok);

RcType retconv(RcActDef actdef, FILE *ifile);

#endif /* RETCODER_H__ */
