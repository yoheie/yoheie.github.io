#include <string.h>
#include "retcoder.h"

int checkopts(int *optnum,char **argv, RcActDef *actdef){

  int i,c=0,h=0;
  char *str;

  for(i=1;i<*optnum;i++){
    if(strcmp(argv[i],"-c") == 0)
      c=1;
    else if(strcmp(argv[i],"-v") == 0){
      actdef -> ifcheck = 1;
    }
    else if(strcmp(argv[i],"-h") == 0 || strcmp(argv[i],"--help") == 0)
      h=1;
    else if(strcmp(argv[i],"--") == 0){
      *optnum = i+1;
      if(h){
        actdef -> ifconvert = 0;
        actdef -> ifcheck = 0;
      }
      else if(c){
        actdef -> ifconvert = 0;
        actdef -> ifcheck = 1;
      }
      return 1;
    }
    else if((argv[i][0] == '-') && (argv[i][1] == 'o')){
      if(argv[i][2] == '\0'){
        i++;
        if(i >= *optnum)
          return 0;
        str = argv[i];
      }
      else{
        str = &argv[i][2];
      }
      if(strcmp(str,"mac") == 0)
        actdef -> otype = cMAC;
      else if(strcmp(str,"unix") == 0)
        actdef -> otype = cUNIX;
      else if(strcmp(str,"dos") == 0)
        actdef -> otype = cDOS;
      else
        return 0;
    }
    else if(argv[i][0] == '-'){
      if(strlen(argv[i]) == 2){
        switch(argv[i][1]){
          case 'm':
            actdef -> otype = cMAC;
            break;
          case 'u':
            actdef -> otype = cUNIX;
            break;
          case 'd':
            actdef -> otype = cDOS;
            break;
          default:
            return 0;
            break;
        }
      }
      else
        return 0;
    }
    else{
      *optnum = i;
      if(h){
        actdef -> ifconvert = 0;
        actdef -> ifcheck = 0;
      }
      else if(c){
        actdef -> ifconvert = 0;
        actdef -> ifcheck = 1;
      }
      return 1;
    }
  }

  if(h){
    actdef -> ifconvert = 0;
    actdef -> ifcheck = 0;
  }
  else if(c){
    actdef -> ifconvert = 0;
    actdef -> ifcheck = 1;
  }
  return 1;
}

void helpmsg(int isoptok){

  FILE *stream;

  char *helpmsg =
    "retcoder - read file ( or stdin ) and check or convert return code\n"
    "  version "VERSION"\n\n"
    " usage:\n"
    "   retcoder [-m|-u|-d|-o (mac|unix|dos)] [-v] [filename] ...\n"
    "   retcoder -c [filename] ...\n"
    "   retcoder (-h|--help)\n"
    " options:\n"
    "   -m,-u,-d\n"
    "   -o (mac|unix|dos)\n"
    "              designate output return code\n"
    "   -v         print check-result to stderr\n"
    "   -c         print check-result to stdout and not convert\n"
    "   -h,--help  print help messave\n"
    "   --         no more options\n";

  if(isoptok == 1)
    stream = stdout;
  else
    stream = stderr;

  fprintf(stream,"%s",helpmsg);

  return;
}
