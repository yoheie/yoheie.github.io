#include "retcoder.h"

RcType retconv(RcActDef actdef, FILE *ifile){

  int c;
  int ifmac = 0,ifunix = 0,ifdos = 0;
  int ifdostmp = 0;
  RcType ifiletype = cNORC;

  while ((c = fgetc(ifile)) != EOF) {
    switch (c) {
      case '\r':
        if(ifdostmp)
          ifmac = 1;
        ifdostmp = 1;
        if(actdef.ifconvert){
          switch (actdef.otype) {
            case cUNIX:
              fputc('\n',stdout);
              break;
            case cDOS:
              fputc('\r',stdout);
              fputc('\n',stdout);
              break;
            case cMAC:
            default:
              fputc('\r',stdout);
              break;
          }
        }
        break;
      case '\n':
        if(ifdostmp){
          ifdostmp = 0;
          ifdos = 1;
          if(actdef.ifconvert && (actdef.otype == cMIX))
            fputc('\n',stdout);
        }
        else{
          ifunix = 1;
          if(actdef.ifconvert){
            switch (actdef.otype) {
              case cMAC:
                fputc('\r',stdout);
                break;
              case cDOS:
                fputc('\r',stdout);
                fputc('\n',stdout);
                break;
              case cUNIX:
              default:
                fputc('\n',stdout);
                break;
            }
          }
        }
        break;
      default:
        if(ifdostmp){
          ifmac = 1;
          ifdostmp = 0;
        }
        if(actdef.ifconvert)
          fputc(c,stdout);
        break;
    }
  }
  if(ifdostmp)
    ifmac = 1;

  if (ifmac && (!ifunix) && (!ifdos))
    ifiletype = cMAC;
  else if ((!ifmac) && ifunix && (!ifdos))
    ifiletype = cUNIX;
  else if ((!ifmac) && (!ifunix) && ifdos)
    ifiletype = cDOS;
  else if (ifmac || ifunix || ifdos)
    ifiletype = cMIX;

  return ifiletype;
}
