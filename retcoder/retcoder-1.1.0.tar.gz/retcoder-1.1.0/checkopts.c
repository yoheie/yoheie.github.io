#include <string.h>
#include "retcoder.h"

int checkopts(int *optnum,char **argv, RcActDef *actdef){

  int i;
  char *str;

  for(i=1;i<*optnum;i++){
    if(strcmp(argv[i],"-c") == 0){
      actdef -> ifconvert = 0;
      actdef -> ifcheck = 1;
      actdef -> itype = cMIX;
      *optnum = i+1;
      return 1;
    }
    else if(strcmp(argv[i],"-v") == 0){
      actdef -> ifcheck = 1;
    }
    else if(strcmp(argv[i],"-h") == 0 || strcmp(argv[i],"--help") == 0){
      /* If option "-h" or "--help" appeared, print usage 
         to standerd output ignoring any other option. */
      actdef -> ifconvert = 0;
      actdef -> ifcheck = 0;
      return 1;
    }
    else if(strcmp(argv[i],"--") == 0){
      *optnum = i+1;
      return 1;
    }
    else if((argv[i][0] == '-') && (argv[i][1] == 'i')){
      if(argv[i][2] == '\0'){
        i++;
        if(i >= *optnum)
          return 0;
        str = argv[i];
      }
      else{
        str = &argv[i][2];
      }
      if(strcmp(str,"mac") == 0)
        actdef -> itype = cMAC;
      else if(strcmp(str,"unix") == 0)
        actdef -> itype = cUNIX;
      else if(strcmp(str,"dos") == 0)
        actdef -> itype = cDOS;
      else
        return 0;
    }
    else if((argv[i][0] == '-') && (argv[i][1] == 'o')){
      if(argv[i][2] == '\0'){
        i++;
        if(i >= *optnum)
          return 0;
        str = argv[i];
      }
      else{
        str = &argv[i][2];
      }
      if(strcmp(str,"mac") == 0)
        actdef -> otype = cMAC;
      else if(strcmp(str,"unix") == 0)
        actdef -> otype = cUNIX;
      else if(strcmp(str,"dos") == 0)
        actdef -> otype = cDOS;
      else
        return 0;
    }
    else if(argv[i][0] == '-'){
      switch(strlen(argv[i])){
        case 2:
          switch(argv[i][1]){
            case 'm':
              actdef -> otype = cMAC;
              break;
            case 'u':
              actdef -> otype = cUNIX;
              break;
            case 'd':
              actdef -> otype = cDOS;
              break;
            default:
              return 0;
              break;
          }
          break;
        case 3:
          switch(argv[i][1]){
            case 'm':
              actdef -> itype = cMAC;
              break;
            case 'u':
              actdef -> itype = cUNIX;
              break;
            case 'd':
              actdef -> itype = cDOS;
              break;
            default:
              return 0;
              break;
          }
          switch(argv[i][2]){
            case 'm':
              actdef -> otype = cMAC;
              break;
            case 'u':
              actdef -> otype = cUNIX;
              break;
            case 'd':
              actdef -> otype = cDOS;
              break;
            default:
              return 0;
              break;
          }
          break;
        default:
          return 0;
          break;
      }
    }
    else{
      *optnum = i;
      return 1;
    }
  }

  return 1;
}

void helpmsg(int isoptok){

  FILE *stream;

  char *helpmsg =
    "retcoder - read file ( or stdin ) and check or convert return code\n"
    "  version "VERSION"\n\n"
    " usage:\n"
    "   retcoder [-[I]O] [-v] [filename] ...\n"
    "   retcoder [-i (mac|unix|dos)] [-o (mac|unix|dos)] [-v] [filename] ...\n"
    "   retcoder -c [filename] ...\n"
    "   retcoder (-h|--help)\n"
    " options:\n"
    "   -[I]O  ( I,O: m(MAC),u(UNIX),d(DOS) )\n"
    "   -i,-o\n"
    "              designate input and output return code\n"
    "   -v         print check-result to stderr\n"
    "   -c         print check-result to stdout and not convert\n"
    "   -h,--help  print help messave\n"
    "   --         no more options\n";

  if(isoptok == 1)
    stream = stdout;
  else
    stream = stderr;

  fprintf(stream,"%s",helpmsg);

  return;
}
