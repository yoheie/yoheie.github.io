#include "retcoder.h"

RcType retconv(RcActDef actdef, FILE *ifile){

  int c;
  int ifmac = 0,ifunix = 0,ifdos = 0;
  int ifdostmp = 0;
  RcType ifiletype = cNORC;

  while ((c = fgetc(ifile)) != EOF) {
    switch (c) {
      case '\r':
        if((actdef.itype == cMIX) || (actdef.itype == cDOS)){
          if(ifdostmp){
            if(actdef.itype == cMIX){
              ifmac = 1;
              if(actdef.ifconvert){
                switch(actdef.otype){
                  case cUNIX:
                    fputc('\n',stdout);
                    break;
                  case cDOS:
                    fputc('\r',stdout);
                    fputc('\n',stdout);
                    break;
                  case cMAC:
                  default:
                    fputc('\r',stdout);
                }
              }
            }
            else if(actdef.ifconvert)
              fputc('\r',stdout);
          }
          ifdostmp = 1;
        }
        else if(actdef.itype == cMAC){
          ifmac = 1;
          if(actdef.ifconvert){
            switch(actdef.otype){
              case cUNIX:
                fputc('\n',stdout);
                break;
              case cDOS:
                fputc('\r',stdout);
                fputc('\n',stdout);
                break;
              case cMAC:
              default:
                fputc('\r',stdout);
            }
          }
        }
        else{
          if(actdef.ifconvert){
            fputc('\r',stdout);
          }
        }
        break;
      case '\n':
        if (actdef.itype == cUNIX){
          ifunix = 1;
          if(actdef.ifconvert){
            switch(actdef.otype){
              case cMAC:
                fputc('\r',stdout);
                break;
              case cDOS:
                fputc('\r',stdout);
                fputc('\n',stdout);
                break;
              case cUNIX:
              default:
                fputc('\n',stdout);
            }
          }
          break;
        }
        else if (ifdostmp){
          ifdostmp = 0;
          ifdos = 1;
          if(actdef.ifconvert){
            switch(actdef.otype){
              case cMAC:
                fputc('\r',stdout);
                break;
              case cUNIX:
                fputc('\n',stdout);
                break;
              case cDOS:
              default:
                fputc('\r',stdout);
                fputc('\n',stdout);
            }
          }
          break;
        }
        else if (actdef.itype == cMIX){
          ifunix = 1;
          if(actdef.ifconvert){
            switch(actdef.otype){
              case cMAC:
                fputc('\r',stdout);
                break;
              case cDOS:
                fputc('\r',stdout);
                fputc('\n',stdout);
                break;
              case cUNIX:
              default:
                fputc('\n',stdout);
            }
          }
          break;
        }
      default:
        if (ifdostmp){
          ifdostmp = 0;
          if(actdef.itype == cMIX){
            ifmac = 1;
            if(actdef.ifconvert){
              switch(actdef.otype){
                case cUNIX:
                  fputc('\n',stdout);
                  break;
                case cDOS:
                  fputc('\r',stdout);
                  fputc('\n',stdout);
                  break;
                case cMAC:
                default:
                  fputc('\r',stdout);
              }
            }
          }
          else if(actdef.ifconvert)
            fputc('\r', stdout);
        }
        if(actdef.ifconvert)
          fputc(c, stdout);
    }
  }
  if(ifdostmp){
    if(actdef.itype == cMIX){
      ifmac = 1;
      if(actdef.ifconvert){
        switch(actdef.otype){
          case cUNIX:
            fputc('\n',stdout);
            break;
          case cDOS:
            fputc('\r',stdout);
            fputc('\n',stdout);
            break;
          case cMAC:
          default:
            fputc('\r',stdout);
        }
      }
    }
    else if(actdef.ifconvert)
      fputc('\r',stdout);
  }

  if (ifmac && (!ifunix) && (!ifdos))
    ifiletype = cMAC;
  else if ((!ifmac) && ifunix && (!ifdos))
    ifiletype = cUNIX;
  else if ((!ifmac) && (!ifunix) && ifdos)
    ifiletype = cDOS;
  else if (ifmac || ifunix || ifdos)
    ifiletype = cMIX;

  return ifiletype;
}
