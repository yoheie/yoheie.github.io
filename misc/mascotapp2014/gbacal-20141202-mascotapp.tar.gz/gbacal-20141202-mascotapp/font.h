#ifndef FONT_H__
#define FONT_H__

#define FONT_X 6
#define FONT_Y 8

extern const unsigned char font[0x80][FONT_Y];

#endif /* FONT_H__ */
