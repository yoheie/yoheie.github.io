#ifndef IMAGE_H__
#define IMAGE_H__

extern const unsigned short _binary_image_all_img_start[];

#define IMAGE_SIZE_X 200
#define IMAGE_SIZE_Y 124
#define IMAGE_START _binary_image_all_img_start

#endif /* IMAGE_H__ */
