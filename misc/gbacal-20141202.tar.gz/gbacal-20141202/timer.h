#ifndef TIMER_H__
#define TIMER_H__

void timer_init(int timer, void (*func)(void));

#endif /* TIMER_H__ */
