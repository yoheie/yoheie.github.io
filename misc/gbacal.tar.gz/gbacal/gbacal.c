#include "stddef.h"
#include "display.h"

#define INITIAL_YEAR 2014
#define INITIAL_MONTH 10

#define LINE_OFFSET 2
#define COLUMN_OFFSET 10 

static const char num_char[10] = "0123456789";

int main(void)
{
	int year = INITIAL_YEAR;
	int month = INITIAL_MONTH;
	int days;
	int weekday;
	char line0_text[7] = "    -  ";
	char line_text[21] = "SU MO TU WE TH FR SA";
	int line;
	int m;
	int n;

	display_init();

	line0_text[0] = num_char[year / 1000 % 10];
	line0_text[1] = num_char[year /  100 % 10];
	line0_text[2] = num_char[year /   10 % 10];
	line0_text[3] = num_char[year /    1 % 10];
	line0_text[5] = num_char[month /  10 % 10];
	line0_text[6] = num_char[month /   1 % 10];

	print_text(LINE_OFFSET+0, COLUMN_OFFSET+6, line0_text);
	print_text(LINE_OFFSET+2, COLUMN_OFFSET+0, line_text);

	if (month == 2) {
		if (year % 4 == 0 && ((year % 100 != 0) || (year % 400 == 0))) {
			days = 29;
		}
		else {
			days = 28;
		}
	}
	else if (month == 4 || month == 6 || month == 9 || month == 11) {
		days = 30;
	}
	else {
		days = 31;
	}

	if (month <= 2) {
		year -= 1;
		month += 12;
	}

	weekday = (year + year/4 - year/100 + year/400 + (month*13 + 8)/5 + 1) % 7;

	line = LINE_OFFSET + 4;

	for (m = 0; m < weekday; m++) {
		line_text[m*3+0] = ' ';
		line_text[m*3+1] = ' ';
	}

	for (n = 1; n < days; n++) {
		line_text[m*3+0] = ((n/10 == 0) ? ' ' : num_char[n/10]);
		line_text[m*3+1] = num_char[n%10];
		if (++m > 6) {
			print_text(line, COLUMN_OFFSET, line_text);
			line += 2;
			m = 0;
		}
	}

	line_text[m*3+0] = ((n/10 == 0) ? ' ' : num_char[n/10]);
	line_text[m*3+1] = num_char[n%10];
	m++;
	while (m < 7) {
		line_text[m*3+0] = ' ';
		line_text[m*3+1] = ' ';
		m++;
	}
	print_text(line, COLUMN_OFFSET, line_text);

	while (1);

	return 0;
}
