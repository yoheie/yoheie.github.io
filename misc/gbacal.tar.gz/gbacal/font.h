#ifndef FONT_H__
#define FONT_H__

#define FONT_X 6
#define FONT_Y 8

extern const unsigned short font[0x80][FONT_Y][FONT_X];

#endif /* FONT_H__ */
