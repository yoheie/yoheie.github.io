#include "color.h"
#include "font.h"

#define o COLOR_WHITE
#define X COLOR_BLACK

#define FONT_NOT_PREPARED { { 0 } }

const unsigned short font[0x80][FONT_Y][FONT_X] = {
	/* 0x00 - 0x1F */
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } },
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } }, 
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } }, 
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } }, 
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } }, 
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } }, 
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } }, 
	{ { 0 } }, { { 0 } }, { { 0 } }, { { 0 } }, 
	/* 0x20 ' ' */
	{
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x21 '!' */
	FONT_NOT_PREPARED,
	/* 0x22 '"' */
	FONT_NOT_PREPARED,
	/* 0x23 '#' */
	FONT_NOT_PREPARED,
	/* 0x24 '$' */
	FONT_NOT_PREPARED,
	/* 0x25 '%' */
	FONT_NOT_PREPARED,
	/* 0x26 '&' */
	FONT_NOT_PREPARED,
	/* 0x27 ''' */
	FONT_NOT_PREPARED,
	/* 0x28 '(' */
	FONT_NOT_PREPARED,
	/* 0x29 ')' */
	FONT_NOT_PREPARED,
	/* 0x2A '*' */
	FONT_NOT_PREPARED,
	/* 0x2B '+' */
	FONT_NOT_PREPARED,
	/* 0x2C ',' */
	FONT_NOT_PREPARED,
	/* 0x2D '-' */
	{
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x2E '.' */
	FONT_NOT_PREPARED,
	/* 0x2F '/' */
	FONT_NOT_PREPARED,
	/* 0x30 '0' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, X, X, o },
		{ X, o, X, o, X, o },
		{ X, X, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x31 '1' */
	{
		{ o, o, X, o, o, o },
		{ o, X, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x32 '2' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, X, o },
		{ o, o, o, X, o, o },
		{ o, o, X, o, o, o },
		{ o, X, o, o, o, o },
		{ X, X, X, X, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x33 '3' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x34 '4' */
	{
		{ o, X, o, X, o, o },
		{ o, X, o, X, o, o },
		{ X, o, o, X, o, o },
		{ X, o, o, X, o, o },
		{ X, X, X, X, X, o },
		{ o, o, o, X, o, o },
		{ o, o, o, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x35 '5' */
	{
		{ X, X, X, X, X, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, X, X, X, o, o },
		{ o, o, o, o, X, o },
		{ o, o, o, o, X, o },
		{ X, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x36 '6' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, o, o },
		{ X, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x37 '7' */
	{
		{ X, X, X, X, X, o },
		{ X, o, o, o, X, o },
		{ o, o, o, X, o, o },
		{ o, o, o, X, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x38 '8' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x39 '9' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, X, o },
		{ o, o, o, o, X, o },
		{ o, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x3A ':' */
	FONT_NOT_PREPARED,
	/* 0x3B ';' */
	FONT_NOT_PREPARED,
	/* 0x3C '<' */
	FONT_NOT_PREPARED,
	/* 0x3D '=' */
	FONT_NOT_PREPARED,
	/* 0x3E '>' */
	FONT_NOT_PREPARED,
	/* 0x3F '?' */
	FONT_NOT_PREPARED,
	/* 0x40 '@' */
	FONT_NOT_PREPARED,
	/* 0x41 'A' */
	{
		{ o, o, X, o, o, o },
		{ o, X, o, X, o, o },
		{ o, X, o, X, o, o },
		{ X, o, o, o, X, o },
		{ X, X, X, X, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x42 'B' */
	{
		{ X, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x43 'C' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x44 'D' */
	{
		{ X, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x45 'E' */
	{
		{ X, X, X, X, X, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, X, X, X, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, X, X, X, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x46 'F' */
	{
		{ X, X, X, X, X, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, X, X, X, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x47 'G' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, X, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x48 'H' */
	{
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, X, X, X, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x49 'I' */
	{
		{ o, X, X, X, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x4A 'J' */
	{
		{ o, X, X, X, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, X, o, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x4B 'K' */
	/* 0x4A 'J' */
	{
		{ X, o, o, o, X, o },
		{ X, o, o, X, o, o },
		{ X, o, X, o, o, o },
		{ X, X, o, o, o, o },
		{ X, o, X, o, o, o },
		{ X, o, o, X, o, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x4C 'L' */
	{
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, X, X, X, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x4D 'M' */
	{
		{ X, o, o, o, X, o },
		{ X, X, o, X, X, o },
		{ X, o, X, o, X, o },
		{ X, o, X, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x4E 'N' */
	{
		{ X, o, o, o, X, o },
		{ X, X, o, o, X, o },
		{ X, X, o, o, X, o },
		{ X, o, X, o, X, o },
		{ X, o, o, X, X, o },
		{ X, o, o, X, X, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x4F 'O' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x50 'P' */
	{
		{ X, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, X, X, X, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, o, o, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x51 'Q' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, X, o, X, o },
		{ X, o, o, X, X, o },
		{ o, X, X, X, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x52 'R' */
	{
		{ X, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, X, X, X, o, o },
		{ X, o, X, o, o, o },
		{ X, o, o, X, o, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x53 'S' */
	{
		{ o, X, X, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, o, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x54 'T' */
	{
		{ X, X, X, X, X, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x55 'U' */
	{
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, X, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x56 'V' */
	{
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, o, X, o, o },
		{ o, X, o, X, o, o },
		{ o, X, o, X, o, o },
		{ o, o, X, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x57 'W' */
	{
		{ X, o, o, o, X, o },
		{ X, o, X, o, X, o },
		{ X, o, X, o, X, o },
		{ X, o, X, o, X, o },
		{ X, o, X, o, X, o },
		{ o, X, o, X, o, o },
		{ o, X, o, X, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x58 'X' */
	{
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, o, X, o, o },
		{ o, o, X, o, o, o },
		{ o, X, o, X, o, o },
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x59 'Y' */
	{
		{ X, o, o, o, X, o },
		{ X, o, o, o, X, o },
		{ o, X, o, X, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, X, o, o, o },
		{ o, o, o, o, o, o },
	},
	/* 0x5A 'Z' */
	{
		{ X, X, X, X, X, o },
		{ o, o, o, o, X, o },
		{ o, o, o, X, o, o },
		{ o, o, X, o, o, o },
		{ o, X, o, o, o, o },
		{ X, o, o, o, o, o },
		{ X, X, X, X, X, o },
		{ o, o, o, o, o, o },
	},
	/* 0x5B '[' */
	/* 0x5C '\' */
	/* 0x5D ']' */
	/* 0x5E '^' */
	/* 0x5F '_' */
	/* 0x60 '`' */
	/* 0x61 'a' */
	/* 0x62 'b' */
	/* 0x63 'c' */
	/* 0x64 'd' */
	/* 0x65 'e' */
	/* 0x66 'f' */
	/* 0x67 'g' */
	/* 0x68 'h' */
	/* 0x69 'i' */
	/* 0x6A 'j' */
	/* 0x6B 'k' */
	/* 0x6C 'l' */
	/* 0x6D 'm' */
	/* 0x6E 'n' */
	/* 0x6F 'o' */
	/* 0x70 'p' */
	/* 0x71 'q' */
	/* 0x72 'r' */
	/* 0x73 's' */
	/* 0x74 't' */
	/* 0x75 'u' */
	/* 0x76 'v' */
	/* 0x77 'w' */
	/* 0x78 'x' */
	/* 0x79 'y' */
	/* 0x7A 'z' */
	/* 0x7B '{' */
	/* 0x7C '|' */
	/* 0x7D '}' */
	/* 0x7E '~' */
};
